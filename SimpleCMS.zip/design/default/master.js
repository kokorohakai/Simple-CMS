//You can adjust this to: 'top','right','bottom' or 'left' default is right.
menustart="right";