<?php
?>
<center>
We're sorry, we cannot find the page you are requesting.<br>
Section: <?=$_SESSION['section']?><br>
SubSection: <?=$_SESSION['subsection']?><br>
File: <?=$filename?><br>
<br>
Simple CMS - A seijinohki PC Services and Software product.<br>
</center>
<br>