// I18N for ObjectInspector

ObjectInspector.I18N = {
};
