<html>
	<head>
		<title>
			Administrator Interface.
		</title>
		<link rel="stylesheet" type="text/css" href="style.css">
		<script language="javascript" type="text/javascript" src="scripts/prototype.js"></script>
	</head>
	<body>
		<table style="width:100%;height:100%;">
			<tr><td style="width:50%;height:50px;"></td><td style="width:300px;height:50px;"></td><td style="width:50%;height:50px;"></td></tr>
			<tr>
				<td style="width:50%;height:100px;"></td>
				<td style="width:300px;text-align:center;background:white;border:3px solid #ccc;">
					Welcome to your Content Management Software Admin interface.
				</td>
				<td style="width:50%;"></td>
			</tr>
			<tr><td style="width:50%;height:100%;"></td><td style="width:300px;height:100%;"></td><td style="width:50%;height:100%;"></td></tr>
		</table>
	</body>
	<script language="javascript" type="text/javascript">
		parent.$('status').innerHTML="Welcome";
	</script>
</html>